#Number Guessing Game Objectives:

# Include an ASCII art logo.
# Allow the player to submit a guess for a number between 1 and 100.
# Check user's guess against actual answer. Print "Too high." or "Too low." depending on the user's answer. 
# If they got the answer correct, show the actual answer to the player.
# Track the number of turns remaining.
# If they run out of turns, provide feedback to the player. 
# Include two different difficulty levels (e.g., 10 guesses in easy mode, only 5 guesses in hard mode).
import random
from art import logo
print(logo)
def guess():
  make_guess = int(input("make a guess"))
  
  if make_guess == GUESS:
  
    print("you choose  coorrect !!! you win")
    return False
  elif make_guess < GUESS:
    print("too small ")
    return True
  elif make_guess > GUESS:
    print("too big")
    return True


def leval(attamp):
  
  game_over = True
  while game_over == True and attamp != 0:
    print(f"you have {attamp} to choose ")
    attamp-=1
    game_over = guess()
  if attamp ==0:
    print("you loose all atamps !! you loose it :(")
        
        

GUESS = random.choice(range(0,101))
# print(GUESS)
level = input("choose difficulty 'hard ' or 'easy' ")
if level == "hard":
  attamp = 5
  leval(attamp)
elif level =="easy":
  attamp = 10
  leval(attamp)

